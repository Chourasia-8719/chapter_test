<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Events extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = "events";

    protected $fillable = [
        'name',
        'category_id',
        'slug',
        'description',
        'from_date',
        'to_date',
        'rating',
        'category_id',
        'activation'
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
        'from_date',
        'to_date'
    ];

    public function events_images()
    {
        return $this->hasMany('App\Models\EventsImage', 'events_id', 'id');
    }

    public function categories()
    {
        return $this->hasOne('App\Models\Category', 'category_id', 'id');
    }
}