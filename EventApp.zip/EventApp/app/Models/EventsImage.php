<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EventsImage extends Model
{
    use HasFactory;

    protected $table = "events_images";

    protected $fillable = [
        'image',
        'events_id'
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'from_date',
        'to_date'
    ];
}