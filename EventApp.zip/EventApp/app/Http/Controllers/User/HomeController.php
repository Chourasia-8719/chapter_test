<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Events;

class HomeController extends Controller
{
    public function index()
    {
        $events = Events::with('events_images')->where(['activation' => 1])->orderBy('id', 'desc')->simplePaginate(1);
        return view('home', compact('events'));
    }

    public function event_details($slug)
    {
        return $events = Events::with('events_images')->where(['slug' => $slug])->orderBy('id', 'desc')->first();
    }
}