<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use Illuminate\Support\Facades\Validator;

class CategoryController extends Controller
{
    public function create()
    {
        return view('admin.category.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|max:8',
            'slug' => 'required|unique:categories,slug',
            'description' => 'required',
            'image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:5000',
        ]);


        if ($request->hasfile('image')) {
            $fileName = time() . '.' . $request->image->extension();

            $request->image->move(public_path('categories'), $fileName);
            Category::create([
                'name' => $request['name'],
                'slug' => $request['slug'],
                'description' => $request['description'],
                'keywords' => $request['keywords'],
                'image' => $fileName,
                'activation' => 1
            ]);
        }
        return redirect('admin/dashboard')->with('success', "Category Added Successfully");
    }

    public function edit($id)
    {
        $data = Category::find($id);
        return view('admin.category.edit', compact('data'));
    }

    public function update(Request $request, $id)
    {

        $request->validate([
            'name' => 'required|max:8',
            'slug' => 'required',
            'description' => 'required',
            'image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:5000',
        ]);

        $data = Category::find($id);

        if ($request->hasfile('image')) {
            if ($data['image'] != '') {
                $path = public_path() . "/categories/" . $data->image;
                unlink($path);
            }
            $fileName = time() . '.' . $request->image->extension();

            $request->image->move(public_path('categories'), $fileName);
        } else {
            $fileName = '';
        }
        $data->update([
            'name' => $request['name'],
            'slug' => $request['slug'],
            'description' => $request['description'],
            'keywords' => $request['keywords'],
            'image' => $fileName,
            'activation' => 1
        ]);
        return redirect('admin/dashboard')->with('success', "Category Updated Successfully");
    }

    public function delete($id)
    {
        $data = Category::find($id);
        if ($data != '') {
            if ($data['image'] != '') {
                $path = public_path() . "/categories/" . $data->image;
                unlink($path);
            }

            $data->delete();
        }

        return redirect('admin/dashboard')->with('success', "Category Deleted Successfully");
    }

    public function updateStatus($id)
    {
        $data = Category::find($id);
        if ($data != '') {
            if ($data['activation'] != 1) {
                $data->update(['activation' => 1]);
            } else {
                $data->update(['activation' => 0]);
            }
        }
    }
}