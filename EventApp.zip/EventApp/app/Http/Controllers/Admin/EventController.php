<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{Events, EventsImage};

class EventController extends Controller
{
    public function create()
    {
        return view('admin.events.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|max:8',
            'slug' => 'required|unique:events,slug',
            'description' => 'required',
            'from_date' => 'required',
            'to_date' => 'required',
        ]);


        $events = Events::create([
            'name' => $request['name'],
            'slug' => $request['slug'],
            'description' => $request['description'],
            'category_id' => $request['category_id'],
            'keywords' => $request['keywords'],
            'from_date' => $request['from_date'],
            'to_date' => $request['to_date'],
            'activation' => 1
        ]);

        if ($files = $request->file('image')) {
            foreach ($files as $file) {
                $name = $file->getClientOriginalName();
                $file->move('events_images', $name);
                EventsImage::insert([
                    'image' =>  $name,
                    'events_id' => $events['id'],
                ]);
            }
        }


        return redirect('admin/dashboard')->with('success', "Events Added Successfully");
    }

    public function edit($id)
    {
        $data = Events::find($id);
        return view('admin.events.edit', compact('data'));
    }

    public function update(Request $request, $id)
    {

        $request->validate([
            'name' => 'required|max:8',
            'slug' => 'required|unique:events,slug',
            'description' => 'required',
            'from_date' => 'required',
            'to_date' => 'required',
        ]);


        $data = Events::find($id);


        $data->update([
            'name' => $request['name'],
            'slug' => $request['slug'],
            'description' => $request['description'],
            'category_id' => $request['category_id'],
            'keywords' => $request['keywords'],
            'from_date' => $request['from_date'],
            'to_date' => $request['to_date'],
            'activation' => 1
        ]);

        return redirect('admin/dashboard')->with('success', "Events Updated Successfully");
    }

    public function delete($id)
    {
        $data = Events::find($id);
        if ($data != '') {

            $data->delete();
        }

        return redirect('admin/dashboard')->with('success', "Events Deleted Successfully");
    }

    public function updateStatus($id)
    {
        $data = Events::find($id);
        if ($data != '') {
            if ($data['activation'] != 1) {
                $data->update(['activation' => 1]);
            } else {
                $data->update(['activation' => 0]);
            }
        }
    }

    public function delete_images($id)
    {
        $data = EventsImage::find($id);
        if ($data['image'] != '') {
            $path = public_path() . "/events_images/" . $data->image;
            unlink($path);
            $data->delete();
        }
        return redirect('admin/dashboard')->with('success', "Event Image Deleted Successfully");
    }
}