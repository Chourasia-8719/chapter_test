
<?php $__env->startSection('title','Admin Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <table class="table table-sm-responsive table-bordered">
        <div class="d-flex justify-content-between">
            <h3>Categories</h3>
            <a href="<?php echo e(route('category')); ?>"><button class="btn btn-warning">Add</button></a>
        </div>

        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">Slug</th>
                <th scope="col">Image</th>
                <th scope="col">Keywords</th>
                <th scope="col">Description</th>
                <th scope="col">Activation</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($category) > 0): ?>
            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($c['id']); ?></th>
                <td><?php echo e($c['name']); ?></td>
                <td><?php echo e($c['slug']); ?></td>
                <td><img src="<?php echo e(URL::asset('categories/'.$c['image'])); ?>" alt="" class="img_style" /></td>
                <td><?php echo $c->keywords; ?></td>
                <td><?php echo $c->description; ?></td>
                <?php if($c['activation'] != 1): ?>
                <td><button class="btn btn-success" onclick="updateStatus(<?php echo e($c['id']); ?>)">Activate</button></td>
                <?php else: ?>
                <td><button class="btn btn-danger" onclick="updateStatus(<?php echo e($c['id']); ?>)">Deactivate</button></td>
                <?php endif; ?>
                <td>
                    <button class="btn btn-success"><a href="<?php echo e(route('category.edit',$c->id)); ?>">Edit</a></button>

                    <button class="btn btn-danger"><a href="<?php echo e(route('category.delete',$c->id)); ?>">Delete</a></button>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <tr>
                <td>No Data FOund</td>
            </tr>
            <?php endif; ?>


        </tbody>

    </table>
    <div style="text-align:right; margin-bottom:10px;">
        <?php echo e($events->links()); ?>

    </div>

    <table class="table table-sm-responsive table-bordered">
        <div class="d-flex justify-content-between">
            <h3>Events</h3>
            <a href="<?php echo e(route('events')); ?>"><button class="btn btn-warning">Add</button></a>
        </div>

        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">Slug</th>
                <th scope="col">Description</th>
                <th scope="col">Activation</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($events) > 0): ?>
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($e['id']); ?></th>
                <td><?php echo e($e['name']); ?></td>
                <td><?php echo e($e['slug']); ?></td>
                <td><?php echo $e->description; ?></td>
                <?php if($e['activation'] != 1): ?>
                <td><button class="btn btn-success" onclick="updateEventStatus(<?php echo e($e['id']); ?>)">Activate</button></td>
                <?php else: ?>
                <td><button class="btn btn-danger" onclick="updateEventStatus(<?php echo e($e['id']); ?>)">Deactivate</button></td>
                <?php endif; ?>
                <td>
                    <button class="btn btn-success"><a href="<?php echo e(route('events.edit',$e->id)); ?>">Edit</a></button>

                    <button class="btn btn-danger"><a href="<?php echo e(route('events.delete',$e->id)); ?>">Delete</a></button>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <tr>
                <td>No Data FOund</td>
            </tr>
            <?php endif; ?>

        </tbody>
    </table>

    <div style="text-align:right; margin-bottom:10px;">
        <?php echo e($events->links()); ?>

    </div>

    <table class="table table-sm-responsive table-bordered">
        <div class="d-flex justify-content-between">
            <h3>Events Images</h3>
        </div>

        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Image</th>
                <th scope="col">Event Id</th>

                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($events) > 0): ?>
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $e['events_images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($i['id']); ?></th>
                <td><img src="<?php echo e(URL::asset('events_images/'.$i['image'])); ?>" alt="" class="img_style" /></td>
                <td><?php echo e($i['events_id']); ?></td>
                <td>

                    <button class="btn btn-danger"><a
                            href="<?php echo e(route('events.images.delete',$i->id)); ?>">Delete</a></button>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <tr>
                <td>No Data FOund</td>
            </tr>
            <?php endif; ?>

        </tbody>
    </table>

    <div style="text-align:right; margin-bottom:10px;">
        <?php echo e($events->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_links'); ?>
<script>
var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

function updateStatus(id) {
    console.log(id);
    $.ajax({
        url: 'category/updateStatus/' + id,
        type: 'GET',
        data: {
            _token: CSRF_TOKEN
        },
        success: function(result) {
            location.reload();
        }
    });
}

function updateEventStatus(id) {
    console.log(id);
    $.ajax({
        url: 'events/updateStatus/' + id,
        type: 'GET',
        data: {
            _token: CSRF_TOKEN
        },
        success: function(result) {
            location.reload();
        }
    });
}

// $(document).ready(function() {
//     $("button").click(function() {

//     });
// });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Anoop_machine_test\EventApp\resources\views/admin/home.blade.php ENDPATH**/ ?>