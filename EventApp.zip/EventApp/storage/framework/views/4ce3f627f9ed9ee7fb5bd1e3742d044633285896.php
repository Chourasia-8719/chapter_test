<?php $__env->startSection('title','Admin Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(count($events) >0): ?>
    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card" style="width: 18rem;">

        <?php $__currentLoopData = $e['events_images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <img class="card-img-top" src="<?php echo e(URL::asset('events_images/'.$i['image'])); ?>" alt="Card image cap">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="card-body">
            <h5 class="card-title"><?php echo e($e['name']); ?></h5>
            <p class="card-text"><?php echo html_entity_decode($e['description']); ?></p>
            <a href="<?php echo e(route('event_details',$e->slug)); ?>"><button>View Detail</button></a>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <div style="text-align:right; margin-bottom:10px;">
        <?php echo e($events->links()); ?>

    </div>



</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Anoop_machine_test\EventApp\resources\views/home.blade.php ENDPATH**/ ?>