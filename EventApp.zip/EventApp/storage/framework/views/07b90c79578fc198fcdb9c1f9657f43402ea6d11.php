
<?php $__env->startSection('title','Admin Category FOrm'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <form action="<?php echo e(route('category.update',$data->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="exampleInputEmail1">Name*</label>
            <input type="text" class="form-control" id="exampleInputEmail1" name="name"
                placeholder="ENter Name of Category" value="<?php echo e($data['name']); ?>">

        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Select Image</label>
            <img src="<?php echo e(URL::asset('categories/'.$data['image'])); ?>" alt="" class="img_style">
            <input type="file" class="form-control" name="image" id="exampleInputPassword1">
        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Select Keywords</label>
            <input type="text" class="form-control" name="keywords" value="<?php echo e($data['keywords']); ?>"
                id="exampleInputPassword1">
        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Select Slug</label>
            <input type="text" class="form-control" name="slug" id="exampleInputPassword1" value="<?php echo e($data['slug']); ?>">
        </div>

        <textarea class="form-control" placeholder="Enter the Description" id="description"
            name="description"><?php echo e($data['description']); ?></textarea>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Anoop_machine_test\EventApp\resources\views/admin/category/edit.blade.php ENDPATH**/ ?>