<?php

use Illuminate\Support\Facades\{Route, Auth};

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [\App\Http\Controllers\User\HomeController::class, 'index'])->name('home');
Route::get('/event_details/{slug}', [\App\Http\Controllers\User\HomeController::class, 'event_details'])->name('event_details');

Route::get('/login', [\App\Http\Controllers\Auth\LoginController::class, 'index']);

Auth::routes();

Route::group(['prefix' => 'admin', 'middleware' => 'admin'], function () {
    Route::get('/dashboard', [\App\Http\Controllers\Admin\HomeController::class, 'index']);
    Route::get('/category/{id}', [\App\Http\Controllers\Admin\CategoryController::class, 'edit'])->name('category.edit');
    Route::post('/category/{id}', [\App\Http\Controllers\Admin\CategoryController::class, 'update'])->name('category.update');
    Route::get('/delete/category/{id}', [\App\Http\Controllers\Admin\CategoryController::class, 'delete'])->name('category.delete');
    Route::get('/category/updateStatus/{id}', [\App\Http\Controllers\Admin\CategoryController::class, 'updateStatus'])->name('category.updateStatus');
    Route::get('/add/category', [\App\Http\Controllers\Admin\CategoryController::class, 'create'])->name('category');
    Route::post('/add/category', [\App\Http\Controllers\Admin\CategoryController::class, 'store'])->name('category.store');

    Route::get('/events/{id}', [\App\Http\Controllers\Admin\EventController::class, 'edit'])->name('events.edit');
    Route::post('/events/{id}', [\App\Http\Controllers\Admin\EventController::class, 'update'])->name('events.update');
    Route::get('/delete/events/{id}', [\App\Http\Controllers\Admin\EventController::class, 'delete'])->name('events.delete');
    Route::get('/events/updateStatus/{id}', [\App\Http\Controllers\Admin\EventController::class, 'updateStatus'])->name('events.updateStatus');
    Route::get('/add/events', [\App\Http\Controllers\Admin\EventController::class, 'create'])->name('events');
    Route::post('/add/events', [\App\Http\Controllers\Admin\EventController::class, 'store'])->name('events.store');

    Route::get('/delete/events_images/{id}', [\App\Http\Controllers\Admin\EventController::class, 'delete_images'])->name('events.images.delete');
});