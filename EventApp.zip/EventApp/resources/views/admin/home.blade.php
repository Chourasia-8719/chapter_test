@extends('layouts.app')
@section('title','Admin Dashboard')
@section('content')
<div class="container">
    <table class="table table-sm-responsive table-bordered">
        <div class="d-flex justify-content-between">
            <h3>Categories</h3>
            <a href="{{route('category')}}"><button class="btn btn-warning">Add</button></a>
        </div>

        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">Slug</th>
                <th scope="col">Image</th>
                <th scope="col">Keywords</th>
                <th scope="col">Description</th>
                <th scope="col">Activation</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            @if(count($category) > 0)
            @foreach($category as $c)
            <tr>
                <th scope="row">{{$c['id']}}</th>
                <td>{{$c['name']}}</td>
                <td>{{$c['slug']}}</td>
                <td><img src="{{ URL::asset('categories/'.$c['image'])}}" alt="" class="img_style" /></td>
                <td>{!! $c->keywords !!}</td>
                <td>{!! $c->description !!}</td>
                @if($c['activation'] != 1)
                <td><button class="btn btn-success" onclick="updateStatus({{$c['id']}})">Activate</button></td>
                @else
                <td><button class="btn btn-danger" onclick="updateStatus({{$c['id']}})">Deactivate</button></td>
                @endif
                <td>
                    <button class="btn btn-success"><a href="{{route('category.edit',$c->id)}}">Edit</a></button>

                    <button class="btn btn-danger"><a href="{{route('category.delete',$c->id)}}">Delete</a></button>
                </td>
            </tr>
            @endforeach
            @else
            <tr>
                <td>No Data FOund</td>
            </tr>
            @endif


        </tbody>

    </table>
    <div style="text-align:right; margin-bottom:10px;">
        {{ $events->links() }}
    </div>

    <table class="table table-sm-responsive table-bordered">
        <div class="d-flex justify-content-between">
            <h3>Events</h3>
            <a href="{{route('events')}}"><button class="btn btn-warning">Add</button></a>
        </div>

        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">Slug</th>
                <th scope="col">Description</th>
                <th scope="col">Activation</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            @if(count($events) > 0)
            @foreach($events as $e)
            <tr>
                <th scope="row">{{$e['id']}}</th>
                <td>{{$e['name']}}</td>
                <td>{{$e['slug']}}</td>
                <td>{!! $e->description !!}</td>
                @if($e['activation'] != 1)
                <td><button class="btn btn-success" onclick="updateEventStatus({{$e['id']}})">Activate</button></td>
                @else
                <td><button class="btn btn-danger" onclick="updateEventStatus({{$e['id']}})">Deactivate</button></td>
                @endif
                <td>
                    <button class="btn btn-success"><a href="{{route('events.edit',$e->id)}}">Edit</a></button>

                    <button class="btn btn-danger"><a href="{{route('events.delete',$e->id)}}">Delete</a></button>
                </td>
            </tr>
            @endforeach
            @else
            <tr>
                <td>No Data FOund</td>
            </tr>
            @endif

        </tbody>
    </table>

    <div style="text-align:right; margin-bottom:10px;">
        {{ $events->links() }}
    </div>

    <table class="table table-sm-responsive table-bordered">
        <div class="d-flex justify-content-between">
            <h3>Events Images</h3>
        </div>

        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Image</th>
                <th scope="col">Event Id</th>

                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            @if(count($events) > 0)
            @foreach($events as $e)
            @foreach($e['events_images'] as $i)
            <tr>
                <th scope="row">{{$i['id']}}</th>
                <td><img src="{{ URL::asset('events_images/'.$i['image'])}}" alt="" class="img_style" /></td>
                <td>{{$i['events_id']}}</td>
                <td>

                    <button class="btn btn-danger"><a
                            href="{{route('events.images.delete',$i->id)}}">Delete</a></button>
                </td>
            </tr>
            @endforeach
            @endforeach
            @else
            <tr>
                <td>No Data FOund</td>
            </tr>
            @endif

        </tbody>
    </table>

    <div style="text-align:right; margin-bottom:10px;">
        {{ $events->links() }}
    </div>
</div>
@endsection

@section('footer_links')
<script>
var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

function updateStatus(id) {
    console.log(id);
    $.ajax({
        url: 'category/updateStatus/' + id,
        type: 'GET',
        data: {
            _token: CSRF_TOKEN
        },
        success: function(result) {
            location.reload();
        }
    });
}

function updateEventStatus(id) {
    console.log(id);
    $.ajax({
        url: 'events/updateStatus/' + id,
        type: 'GET',
        data: {
            _token: CSRF_TOKEN
        },
        success: function(result) {
            location.reload();
        }
    });
}

// $(document).ready(function() {
//     $("button").click(function() {

//     });
// });
</script>

@endsection