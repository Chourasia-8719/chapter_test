@extends('layouts.app')
@section('title','Admin Category FOrm')
@section('content')
<div class="container">
    <form action="{{route('category.update',$data->id)}}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label for="exampleInputEmail1">Name*</label>
            <input type="text" class="form-control" id="exampleInputEmail1" name="name"
                placeholder="ENter Name of Category" value="{{$data['name']}}">

        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Select Image</label>
            <img src="{{ URL::asset('categories/'.$data['image'])}}" alt="" class="img_style">
            <input type="file" class="form-control" name="image" id="exampleInputPassword1">
        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Select Keywords</label>
            <input type="text" class="form-control" name="keywords" value="{{$data['keywords']}}"
                id="exampleInputPassword1">
        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Select Slug</label>
            <input type="text" class="form-control" name="slug" id="exampleInputPassword1" value="{{$data['slug']}}">
        </div>

        <textarea class="form-control" placeholder="Enter the Description" id="description"
            name="description">{{$data['description']}}</textarea>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

@endsection