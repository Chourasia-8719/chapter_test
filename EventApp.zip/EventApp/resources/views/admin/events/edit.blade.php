@extends('layouts.app')
@section('title','Admin Category FOrm')
@section('content')
<div class="container">
    <form action="{{route('events.update',$data->id)}}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label for="exampleInputEmail1">Name*</label>
            <input type="text" class="form-control" id="exampleInputEmail1" name="name"
                placeholder="ENter Name of Event" value="{{$data['name']}}">

        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Select Category</label>
            <select name="category_id" id="" class="form-control">
                @foreach($categories as $c)
                <option value="{{$c['id']}}" {{$data->category_id == $c->id  ? 'selected' : ''}}>
                    {{$c['name']}}
                </option>
                @endforeach
            </select>
        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Event From</label>
            <input type="date" class="form-control" name="from_date" id="exampleInputPassword1"
                value="{{ \Carbon\Carbon::parse($data->to_date)->format('dd-mm-yyyy')}}">
        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Event To</label>
            <input type="date" class="form-control" name="to_date" id="exampleInputPassword1"
                value="{{ \Carbon\Carbon::parse($data->to_date)->format('dd-mm-yyyy')}}">
        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Select Slug</label>
            <input type="text" class="form-control" name="slug" id="exampleInputPassword1" value="{{$data['slug']}}">
        </div>

        <textarea class="form-control" placeholder="Enter the Description" id="description"
            name="description">{{$data['description']}}</textarea>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

@endsection