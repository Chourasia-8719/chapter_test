@extends('layouts.app')
@section('title','Admin Dashboard')
@section('content')
<div class="container">
    @if(count($events) >0)
    @foreach($events as $e)
    <div class="card" style="width: 18rem;">

        @foreach($e['events_images'] as $i)

        <img class="card-img-top" src="{{ URL::asset('events_images/'.$i['image'])}}" alt="Card image cap">
        @endforeach
        <div class="card-body">
            <h5 class="card-title">{{$e['name']}}</h5>
            <p class="card-text">{!!html_entity_decode($e['description'])!!}</p>
            <a href="{{route('event_details',$e->slug)}}"><button>View Detail</button></a>
        </div>
    </div>
    @endforeach
    @endif
    <div style="text-align:right; margin-bottom:10px;">
        {{ $events->links() }}
    </div>



</div>
@endsection